1	//lab 6 question:Create a component that updates the document title every time the count is incremented. Use useEffect() to update the title whenever the count state changes.
2	import React, { useState, useEffect } from 'react';
3
4	const TitleUpdater = () => {
5	  const [count, setCount] = useState(0);
6
7	  useEffect(() => {
8	    document.title = Count: ${count};
9	  }, [count]);  // Effect runs only when count changes
10
11	  return (
12	    <div>
13	      <h1>Count: {count}</h1>
14	      <button onClick={() => setCount(count + 1)}>Increment</button>
15	    </div>
16	  );
17	};
18	
19	export default TitleUpdater;