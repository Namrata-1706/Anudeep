1	import React, { useState } from 'react';
2
3	const Counter = () => {
4	  const [count, setCount] = useState(0);
5
6	  return (
7	    <div>
8	      <h1>Count: {count}</h1>
9	      <button onClick={() => setCount(count + 1)}>Increment</button>
10	      <button onClick={() => setCount(count - 1)}>Decrement</button>
11	    </div>
12	  );
13	};
14
15	export default Counter;